package edu.iit.model;

public class User  extends SmartParkingBoardCommitee{
	private static int sp_userid;
	private static int us_slots;
	private static String sp_userName;
	private void add_Car(){}

	private void manage_car(){
		
	}
	private void booking_History(){
		
	}
	private void book_Slot(){
		
	}
}

package edu.iit.model;

public class AddCar extends SmartParkingBoardCommitee implements CarInfo{

	@Override
	public void addCarNumber() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addCarModel() {
		// TODO Auto-generated method stub
		
	}

}

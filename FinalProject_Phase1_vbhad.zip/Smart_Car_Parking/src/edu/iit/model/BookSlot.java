package edu.iit.model;

public class BookSlot extends User{
	
	public  String bookid="";
	public String bs_publicplace="";
	public String bs_hospital="";
	public String bs_apt="";
	public String bs_mail="";
	public String totalSlots="";
	
	public void selectCategory() {
		// TODO Auto-generated method stub
		
	}
	public void selectSlot() {
		// TODO Auto-generated method stub
		
	}
	public void selectVenue() {
		// TODO Auto-generated method stub
		
	}
}

package edu.iit.model;

public class ManageUser extends AddCar {
	public  String sp_userName="";
	public  String sp_carName="";
	public  String sp_carModel="";
	
	public void updateUserName() {
		// TODO Auto-generated method stub
		
	}
	public void updateCarNumber() {
		// TODO Auto-generated method stub
		
	}
	public void updateCarModel() {
		// TODO Auto-generated method stub
		
	}
}

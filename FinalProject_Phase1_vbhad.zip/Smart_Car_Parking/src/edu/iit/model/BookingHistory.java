package edu.iit.model;

public class BookingHistory extends User {
	
	private String bookdate;
	private String bookvenue;
	private String carmodel;
	private String carname;
	private int sp_userid;
	public int amountpaid;
	
	public void select_category() {
		
	}
	
	public void select_venue() {
		
	}
	
	public void amountpaid() {
		
	}

}

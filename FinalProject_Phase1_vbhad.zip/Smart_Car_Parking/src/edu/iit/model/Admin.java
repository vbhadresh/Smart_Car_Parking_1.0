package edu.iit.model;

public class Admin extends SmartParkingBoardCommitee {
private static int user_id;
private static int ad_total_slots;
private static String ad_venue;

private void addVenue(){}

private void addSlots(){
	
}
private void selectCategory(){
	
}
}

package edu.iit.model;

public interface CarInfo {
	public  String car_name="";
	public String car_model="";

public void addCarNumber();
public void addCarModel();
}

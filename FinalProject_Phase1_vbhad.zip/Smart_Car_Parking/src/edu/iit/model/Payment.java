package edu.iit.model;

public class Payment extends BookSlot {

	public int pd_amt;
	public String pd_emailID="";
	public String pd_payID="";
	public String bs_apt="";
	public String bs_mail="";
	public int book_id;
	
	public void calcuateAmount() {
		// TODO Auto-generated method stub
		
	}
	public void selectVenue() {
		// TODO Auto-generated method stub
		
	}	
}

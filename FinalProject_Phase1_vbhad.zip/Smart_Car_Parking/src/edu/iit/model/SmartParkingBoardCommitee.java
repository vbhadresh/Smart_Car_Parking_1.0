package edu.iit.model;

public class SmartParkingBoardCommitee {

}
